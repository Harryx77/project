//nodejs v14.16.1
//npm install ethers
//npm install express
//npm install chalk
//npm install readline-sync

const cfg = require('./cfg.json')
const readlineSync = require('readline-sync');
const ethers = require('ethers');
const express = require('express');
const chalk = require('chalk');
const app = express();

console.log('[+] Auto Sniper Token\n')

var jumlahsnipe = readlineSync.question('[+] Total Snipe : ');
var slip = readlineSync.question('[+] Setting Slip Page : ');
var tokensniper = readlineSync.question('[+] Token Sniper : ');
const data = {
  WBNB: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c', //Contract Address WBNB 
  to_Snipe: tokensniper,  // Token yang Mau Di Snipe
  factory: '0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73',  //PCS V2 factory
  router: '0x10ED43C718714eb63d5aA57B78B54704E256024E', //PCS V2 router
  recipient: cfg.address_bsc, //Wallet Address BSC
  Jumlah_WBNB : jumlahsnipe, //Jumlah WBNB yang mau dipkek buat snipe
  Slippage : slip, //Setting SP %
  gasPrice : '5', //Setting gwei
  gasLimit : '145684' //Setting Gas Limit , Minim 21000
}

let initialLiquidityDetected = false;

const bscMainnetUrl = 'https://bsc-dataseed.binance.org/' //Binance Mainnet
const mnemonic = cfg.mnemonic; //Phrase Wallet
const provider = new ethers.providers.JsonRpcProvider(bscMainnetUrl)
const wallet = ethers.Wallet.fromMnemonic(mnemonic);
const account = wallet.connect(provider);

const factory = new ethers.Contract(
  data.factory,
  ['function getPair(address tokenA, address tokenB) external view returns (address pair)'],
  account
);

const router = new ethers.Contract(
  data.router,
  [
    'function getAmountsOut(uint amountIn, address[] memory path) public view returns (uint[] memory amounts)',
    'function swapExactTokensForTokens(uint amountIn, uint amountOutMin, address[] calldata path, address to, uint deadline) external returns (uint[] memory amounts)'
  ],
  account
);

const run = async () => {
  const tokenIn = data.WBNB;
  const tokenOut = data.to_Snipe;
  const pairAddress = await factory.getPair(tokenIn, tokenOut);

  console.log(chalk.blue(`pairAddress: ${pairAddress}`));
  if (pairAddress !== null && pairAddress !== undefined) {
    console.log("pairAddress.toString().indexOf('0x0000000000000')", pairAddress.toString().indexOf('0x0000000000000'));
    if (pairAddress.toString().indexOf('0x0000000000000') > -1) {
      console.log(chalk.red(`pairAddress ${pairAddress} Tidak Terdeteksi. Restart Bot!`));
      return;
    }
  }

  const pair = new ethers.Contract(pairAddress, ['event Mint(address indexed sender, uint amount0, uint amount1)'], account);

  pair.on('Mint', async (sender, amount0, amount1) => {
    if(initialLiquidityDetected === true) {
        return;
    }

    initialLiquidityDetected = true;

   const amountIn = ethers.utils.parseUnits(`${data.Jumlah_WBNB}`, 'ether');
   const amounts = await router.getAmountsOut(amountIn, [tokenIn, tokenOut]);
 
   const amountOutMin = amounts[1].sub(amounts[1].div(`${data.Slippage}`)); 
 
   console.log(
    chalk.green.inverse(`Liquidity Sudah Ditambah Dev\n`)
     +
     `Beli Token
     =================
     tokenIn: ${amountIn.toString()} ${tokenIn} (WBNB)
     tokenOut: ${amountOutMin.toString()} ${tokenOut}
   `);

   console.log('Proses Transaksi.....');
   console.log(chalk.green(`amountIn: ${amountIn}`));
   console.log(chalk.green(`amountOutMin: ${amountOutMin}`));
   console.log(chalk.green(`tokenIn: ${tokenIn}`));
   console.log(chalk.green(`tokenOut: ${tokenOut}`));
   console.log(chalk.green(`data.recipient: ${data.recipient}`));
   console.log(chalk.green(`data.gasLimit: ${data.gasLimit}`));
   console.log(chalk.green(`data.gasPrice: ${ethers.utils.parseUnits(`${data.gasPrice}`, 'gwei')}`));

   const tx = await router.swapExactTokensForTokens(
     amountIn,
     amountOutMin,
     [tokenIn, tokenOut],
     data.recipient,
     Date.now() + 1000 * 60 * 10, //10 minutes
     {
       'gasLimit': data.gasLimit,
       'gasPrice': ethers.utils.parseUnits(`${data.gasPrice}`, 'gwei')
   });
 
   const receipt = await tx.wait(); 
   console.log('Sukses Transaksi');
   console.log(receipt);
  });
}

run();

const PORT = 5000;

app.listen(PORT, (console.log(chalk.green(`Menunggu Liquid Ditambahkan ${data.to_Snipe}`))));
